Place your Lighthouse accessibility screenshots here:
Problem1.png
Fix1.png
Problem2.png
Fix2.png
