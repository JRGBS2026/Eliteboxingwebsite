# Submission Checklist

- [ ] Open and test every page
- [ ] Confirm all 12 images display
- [ ] Test search and every category filter
- [ ] Test add, remove and quantity controls
- [ ] Test on mobile, tablet and desktop sizes
- [ ] Run Chrome Lighthouse accessibility audit
- [ ] Save before screenshots as `evidence/Problem1.png` and `evidence/Problem2.png`
- [ ] Make two accessibility improvements
- [ ] Save after screenshots as `evidence/Fix1.png` and `evidence/Fix2.png`
- [ ] Upload the complete project to GitHub
- [ ] Record the 8–10 minute presentation
- [ ] Submit the ZIP, GitHub link and presentation recording on Moodle
