# Elite Boxing E-Commerce Website

A responsive front-end boxing equipment store built with HTML, CSS and vanilla JavaScript DOM manipulation only.

## Run the project
1. Extract the ZIP folder.
2. Open `index.html` in a browser.
3. For the best result, open the folder in Visual Studio Code and use the Live Server extension.

## Main features
- Five HTML pages: Home, Products, Cart, About and Contact
- Twelve boxing products using the supplied Elite Boxing images
- Product search and category filters
- Add-to-cart, remove, increase and decrease quantity
- Automatic subtotal and total calculations
- Cart data saved in browser localStorage
- Mobile, tablet and desktop responsive design
- Contact-form validation
- Semantic HTML, alt text and a skip link

## GitHub
Create a new GitHub repository, upload every file and folder, then enable GitHub Pages from Settings > Pages.

## Technologies
HTML5, CSS3 and JavaScript only. No frameworks, libraries or backend.
