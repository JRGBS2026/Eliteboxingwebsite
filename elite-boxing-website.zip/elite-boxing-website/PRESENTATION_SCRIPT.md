# Elite Boxing Presentation Script (8–10 minutes)

1. **Introduction** – Explain that Elite Boxing is a responsive front-end e-commerce website for premium boxing equipment.
2. **Brand and design** – Discuss the black-and-gold colour scheme, consistent typography, spacing, buttons, shadows and hover effects.
3. **Home page** – Demonstrate the navigation, hero section, category cards and featured products.
4. **Products page** – Show all 12 products, then demonstrate the search box and category filters.
5. **Shopping cart** – Add products, open the cart, increase and decrease quantities, remove an item and show the automatic total.
6. **JavaScript** – Explain that the product list is stored as JavaScript objects and the DOM creates the cards dynamically. Mention localStorage.
7. **Responsive design** – Resize the browser or use Chrome device mode to show desktop, tablet and mobile layouts.
8. **Contact validation** – Submit incomplete information, then submit valid information to show validation feedback.
9. **Accessibility** – Mention alt text, semantic sections, labels, colour contrast, keyboard controls and Lighthouse testing.
10. **Conclusion** – Summarise how the website meets HTML, CSS, JavaScript, UX, accessibility and responsive-design requirements.
